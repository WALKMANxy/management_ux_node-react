// src/pages/client/ClientDashboard.tsx
import React from "react";

const ClientDashboard: React.FC = () => {
  return (
    <div>
      <h1>Client Dashboard</h1>
    </div>
  );
};

export default ClientDashboard;
