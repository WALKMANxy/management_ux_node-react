

const TestComponents = () => {
  return (
    console.log("Hello Mate")
   
  );
};

export default TestComponents;
