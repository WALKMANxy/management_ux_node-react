// src/models/models.ts

import { ColDef } from "ag-grid-community";
import { ReactNode } from "react";

export type UserRole = "admin" | "agent" | "client" | "guest";

export type AuthState = {
  isLoggedIn: boolean;
  userRole: UserRole;
  id: string | null;
};

export type ClientsState = {
  clients: Client[];
  status: "idle" | "loading" | "succeeded" | "failed";
  error: string | null;
};

export type CalendarState = {
  visits: Visit[];
};

export type AuthHandlersProps = {
  selectedRole: "admin" | "agent" | "client";
  selectedAgent: string;
  selectedClient: string;
  agents: Agent[];
};

export type SearchResult = {
  id: string;
  name: string;
  type: string;
  // Article-specific properties
  articleId?: string;
  brand?: string;
  lastSoldDate?: string;
  // Client-specific properties
  province?: string;
  phone?: string;
  paymentMethod?: string;
  address?: string;
  email?: string;
  agent?: string;
  // Promo-specific properties
  discountAmount?: string;
  isEligible?: boolean;
  startDate?: string;
  endDate?: string;
  // Alert-specific properties
  dateIssued?: string;
  reason?: string;
  severity?: string;
};

export type SearchParams = {
  query: string;
  filter: string;
  results?: SearchResult[];
};

export type SearchState = {
  query: string;
  results: SearchResult[];
  status: "idle" | "loading" | "succeeded" | "failed";
  error: string | null;
};

export type GlobalSearchProps = {
  filter?: string;
  onSelect?: (item: string) => void;
  placeholder?: string;
};

export type DetailProps = {
  detail: { [key: string]: any };
  isLoading: boolean;
};

export type HistoryProps = {
  history: { [key: string]: any }[];
};

export type SearchResultsProps = {
  onSelect: (item: string) => void;
  selectedIndex: number;
  results: SearchResult[];
};

export type SidebarProps = {
  onToggle: (isOpen: boolean) => void;
};

export type SalesDistributionProps = {
  salesDistributionData: { label: string; value: number }[];
};

export type ActivePromotionsProps = {
  selectedClient?: Client | null;
  agentDetails?: { clients: Client[] } | null;
};

export type SpentThisMonthProps = {
  amount: string;
};

export type SpentThisYearProps = {
  amount: string;
};

export type Props = {
  children: ReactNode;
};

export type State = {
  hasError: boolean;
};

export type ClientListProps = {
  quickFilterText: string;
  setQuickFilterText: (value: string) => void;
  startDate: string;
  setStartDate: (value: string) => void;
  endDate: string;
  setEndDate: (value: string) => void;
  filteredClients: () => any[];
  columnDefs: any[];
  gridRef: any;
  handleMenuOpen: (event: React.MouseEvent<HTMLButtonElement>) => void;
  handleMenuClose: () => void;
  anchorEl: HTMLElement | null;
  exportDataAsCsv: () => void;
  isClientListCollapsed: boolean;
  setClientListCollapsed: (value: boolean) => void;
  isMobile: boolean;
};

export type TopArticleTypeProps = {
  articles: { id: string; name: string; amount: number }[];
};

export type TotalEarningProps = {
  totalEarning: number;
  isLoading: boolean;
};

export type UpcomingVisitsProps = {
  selectedClient?: Client | null;
  agentDetails?: { clients: Client[] } | null;
};

export type AGGridTableProps = {
  columnDefs: ColDef[];
  rowData: any[];
  paginationPageSize: number;
  quickFilterText: string; // Added quickFilterText prop
};

export type MovementsHistoryProps = {
  movements: Movement[];
};

export type ClientDetailsProps = {
  selectedClient: Client | null;
  isClientDetailsCollapsed: boolean;
  setClientDetailsCollapsed: (value: boolean) => void;
  isLoading: boolean;
  ref: React.Ref<HTMLDivElement>; // Add ref prop
};

export type Visit = {
  date: string;
  note: string;
};

export type MovementDetail = {
  articleId: string;
  name: string;
  brand: string;
  priceSold: string;
  priceBought: string;
};

export type Movement = {
  id: string;
  discountCategory: string;
  details: MovementDetail[];
  unpaidAmount: string;
  paymentDueDate: string;
  dateOfOrder: string;
};

export type Promo = {
  id: string;
  name: string;
  discount: string;
  startDate: string;
  endDate: string;
};

export type Client = {
  id: string;
  name: string;
  extendedName?: string; // New property
  province?: string;
  phone?: string;
  totalOrders: number;
  totalRevenue: string;
  unpaidRevenue: string;
  address?: string;
  email?: string;
  pec?: string; // New property
  taxCode?: string; // New property
  extendedTaxCode?: string; // New property
  paymentMethodID?: string; // New property
  paymentMethod?: string; // New property
  visits: Visit[];
  agent: string;
  movements: Movement[];
  promos: Promo[];
};

export type Agent = {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  clients: Client[];
};

export type Alert = {
  id: string;
  message: string;
  date: string;
  severity: "low" | "medium" | "high";
};

export type DataState = {
  clients: Client[];
  clientIndex: Map<string, Client>;
  status: "idle" | "loading" | "succeeded" | "failed";
  error: string | null;
};

export type FetchDataPayload = {
  clients: Client[];
  clientIndex: Map<string, Client>;
};
